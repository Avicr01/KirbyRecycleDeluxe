#pragma once
#include "Base.h"
class Fruta :
    public Base
{
private:
public:
    Fruta();
    Fruta(int _x, int _y, int _w, int _h);
    ~Fruta();
};

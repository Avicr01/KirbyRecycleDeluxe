#pragma once
#include "Base.h"
class Pulpo :
    public Base
{
private:
public:
    Pulpo();
    Pulpo(int _x, int _y);
    ~Pulpo();
};

#pragma once
#include "Base.h"
class Arana :
    public Base
{
private:
public:
    Arana();
    Arana(int _x, int _y, int _w, int _h);
    ~Arana();
};


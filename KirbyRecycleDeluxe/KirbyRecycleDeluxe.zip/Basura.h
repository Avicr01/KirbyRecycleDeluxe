#pragma once
#include "Base.h"
class Basura :
    public Base
{
private:
public:
    Basura();
    Basura(int _x, int _y, int _w, int _h);
    ~Basura();
};

#pragma once
#include "Base.h"
class Anaconda :
    public Base
{
private:
public:
    Anaconda();
    Anaconda(int _x, int _y, int _w, int _h);
    ~Anaconda();
};
